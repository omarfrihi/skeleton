const Example = () => <>Example</>;

export default Example;
